package com.alpha.topmonitor

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.alpha.topmonitor.monitor.CpuMonitor
import com.alpha.topmonitor.monitor.RamMonitor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class RamMonitorInstrumentedTest {

    @Test
    fun ramFiguresAreConsistent() {
        val ctx = InstrumentationRegistry.getInstrumentation().targetContext
        val s = RamMonitor(ctx).sample()
        assertTrue(s.totalBytes > 0)
        assertTrue(s.usedBytes in 0..s.totalBytes)
        assertEquals(s.totalBytes - s.availBytes, s.usedBytes)
        assertTrue(s.percent!! in 0f..100f)
    }

    @Test
    fun cpuNeverReportsMadeUpValues() {
        val monitor = CpuMonitor()
        monitor.sample()
        Thread.sleep(500)
        val s = monitor.sample()
        // System CPU is either a real 0..100 figure or null (N/A) when Android blocks /proc/stat.
        s.systemPercent?.let { assertTrue(it in 0f..100f) }
        assertTrue(s.cores >= 1)
    }
}
