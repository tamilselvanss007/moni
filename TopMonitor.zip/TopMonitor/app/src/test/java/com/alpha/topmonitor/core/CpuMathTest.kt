package com.alpha.topmonitor.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class CpuMathTest {

    private val first = """
        cpu  100 0 50 800 50 0 0 0 0 0
        cpu0 50 0 25 400 25 0 0 0 0 0
        intr 12345
    """.trimIndent()

    private val second = """
        cpu  200 0 100 1500 100 0 0 0 0 0
        cpu0 100 0 50 750 50 0 0 0 0 0
    """.trimIndent()

    @Test
    fun parsesAggregateLine() {
        val t = CpuMath.parseProcStat(first)
        assertNotNull(t)
        assertEquals(1000L, t!!.total)
        assertEquals(150L, t.busy) // total minus idle (800) and iowait (50)
    }

    @Test
    fun ignoresPerCoreLines() {
        val t = CpuMath.parseProcStat("cpu0 1 2 3 4 5 6 7 8\n")
        assertNull(t)
    }

    @Test
    fun rejectsEmptyOrMalformedInput() {
        assertNull(CpuMath.parseProcStat(""))
        assertNull(CpuMath.parseProcStat("cpu  abc def"))
        assertNull(CpuMath.parseProcStat("cpu  1 2 3"))
    }

    @Test
    fun usageBetweenTwoReadings() {
        val a = CpuMath.parseProcStat(first)!!
        val b = CpuMath.parseProcStat(second)!!
        // delta total 900, delta busy 150
        assertEquals(16.67f, CpuMath.usagePercent(a, b)!!, 0.01f)
    }

    @Test
    fun usageIsNullWhenCountersDoNotAdvance() {
        val a = CpuMath.parseProcStat(first)!!
        assertNull(CpuMath.usagePercent(a, a))
    }

    @Test
    fun usageIsNullWhenCountersGoBackwards() {
        val a = CpuMath.parseProcStat(first)!!
        val b = CpuMath.parseProcStat(second)!!
        assertNull(CpuMath.usagePercent(b, a))
    }

    @Test
    fun fullyBusyIsOneHundred() {
        val a = CpuTimes(busy = 0, total = 100)
        val b = CpuTimes(busy = 100, total = 200)
        assertEquals(100f, CpuMath.usagePercent(a, b)!!, 0.001f)
    }

    @Test
    fun appPercentIsShareOfAllCores() {
        // 400 ms of CPU in 1000 ms on 4 cores = 10 % of total capacity
        assertEquals(10f, CpuMath.appPercent(400, 1000, 4)!!, 0.001f)
    }

    @Test
    fun appPercentRejectsBadInput() {
        assertNull(CpuMath.appPercent(10, 0, 4))
        assertNull(CpuMath.appPercent(-1, 1000, 4))
        assertNull(CpuMath.appPercent(10, 1000, 0))
    }
}
