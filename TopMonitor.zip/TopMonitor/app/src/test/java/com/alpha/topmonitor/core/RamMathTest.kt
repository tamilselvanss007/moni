package com.alpha.topmonitor.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class RamMathTest {
    @Test
    fun usedIsTotalMinusAvailable() {
        assertEquals(6000L, RamMath.usedBytes(8000L, 2000L))
    }

    @Test
    fun percentIsUsedOverTotal() {
        assertEquals(75f, RamMath.percent(8000L, 2000L)!!, 0.001f)
    }

    @Test
    fun availableAboveTotalNeverGoesNegative() {
        assertEquals(0L, RamMath.usedBytes(1000L, 1500L))
        assertEquals(0f, RamMath.percent(1000L, 1500L)!!, 0.001f)
    }

    @Test
    fun zeroTotalHasNoPercent() {
        assertNull(RamMath.percent(0L, 0L))
        assertEquals(0L, RamMath.usedBytes(0L, 0L))
    }
}
