package com.alpha.topmonitor.monitor

data class CpuSample(
    /** System-wide CPU use, or null when Android does not let this app read it. */
    val systemPercent: Float?,
    /** This app's own CPU use as a share of all cores. */
    val appPercent: Float?,
    val cores: Int,
    /** Kernel-reported (scaling_cur_freq) average across readable cores, in kHz. */
    val avgFreqKhz: Long?,
    val maxFreqKhz: Long?,
    /** False once /proc/stat has proven unreadable on this device. */
    val systemStatAvailable: Boolean
)

data class RamSample(
    val totalBytes: Long,
    val availBytes: Long,
    val usedBytes: Long,
    val percent: Float?,
    val lowMemory: Boolean,
    /** Proportional set size of this app's process, or null if unreadable. */
    val appPssBytes: Long?
)

data class Snapshot(val timeMs: Long, val cpu: CpuSample, val ram: RamSample)

data class HistoryPoint(val timeMs: Long, val cpu: Float?, val ram: Float?)
