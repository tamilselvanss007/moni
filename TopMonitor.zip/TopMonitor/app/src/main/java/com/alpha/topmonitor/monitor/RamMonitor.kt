package com.alpha.topmonitor.monitor

import android.app.ActivityManager
import android.content.Context
import android.os.Debug
import android.os.SystemClock
import com.alpha.topmonitor.core.RamMath

/** System-wide RAM from ActivityManager.MemoryInfo, plus this app's own memory kept separate. */
class RamMonitor(context: Context) {
    private val activityManager =
        context.applicationContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    private var lastPssAt = 0L
    private var lastPss: Long? = null

    fun sample(): RamSample {
        val info = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(info)
        return RamSample(
            totalBytes = info.totalMem,
            availBytes = info.availMem,
            usedBytes = RamMath.usedBytes(info.totalMem, info.availMem),
            percent = RamMath.percent(info.totalMem, info.availMem),
            lowMemory = info.lowMemory,
            appPssBytes = appPss()
        )
    }

    // Reading PSS walks the process maps, so refresh it at most every 5 seconds.
    private fun appPss(): Long? {
        val now = SystemClock.elapsedRealtime()
        if (lastPssAt != 0L && now - lastPssAt < 5000L) return lastPss
        lastPssAt = now
        lastPss = try {
            val mi = Debug.MemoryInfo()
            Debug.getMemoryInfo(mi)
            mi.totalPss * 1024L
        } catch (e: Exception) {
            null
        }
        return lastPss
    }
}
