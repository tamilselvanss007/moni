package com.alpha.topmonitor.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View
import androidx.core.graphics.ColorUtils
import com.alpha.topmonitor.data.PerformanceRepository

/** Small dependency-free line chart for 0–100 % history. Null entries leave a gap. */
class SparklineView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var values: List<Float?> = emptyList()
    private var emptyText = ""

    var lineColor: Int = 0xFF4DD0E1.toInt()
        set(value) {
            field = value
            line.color = value
            rebuildShader()
            invalidate()
        }

    private val density = resources.displayMetrics.density
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
        color = lineColor
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val grid = Paint().apply {
        color = 0x24FFFFFF
        strokeWidth = density
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x99FFFFFF.toInt()
        textSize = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_SP, 10f, resources.displayMetrics
        )
    }

    private val padLeft = 30f * density
    private val padRight = 4f * density
    private val padTop = 6f * density
    private val padBottom = 6f * density

    fun setData(data: List<Float?>, emptyMessage: String) {
        values = data
        emptyText = emptyMessage
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuildShader()
    }

    private fun rebuildShader() {
        if (height == 0) return
        fill.shader = LinearGradient(
            0f, padTop, 0f, height - padBottom,
            ColorUtils.setAlphaComponent(lineColor, 90),
            ColorUtils.setAlphaComponent(lineColor, 0),
            Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val left = padLeft
        val right = width - padRight
        val top = padTop
        val bottom = height - padBottom
        val plotH = bottom - top

        for (pct in intArrayOf(0, 50, 100)) {
            val y = bottom - plotH * pct / 100f
            canvas.drawLine(left, y, right, y, grid)
            canvas.drawText(pct.toString(), 2f * density, y + label.textSize / 3f, label)
        }

        if (values.none { it != null }) {
            val w = label.measureText(emptyText)
            canvas.drawText(emptyText, (left + right - w) / 2f, (top + bottom) / 2f, label)
            return
        }

        val capacity = PerformanceRepository.MAX_POINTS
        val step = (right - left) / (capacity - 1)
        val n = values.size
        var i = 0
        while (i < n) {
            if (values[i] == null) {
                i++
                continue
            }
            val stroke = Path()
            val area = Path()
            var firstX = 0f
            var lastX = 0f
            var started = false
            while (i < n) {
                val v = values[i] ?: break
                val x = right - (n - 1 - i) * step
                val y = bottom - plotH * v.coerceIn(0f, 100f) / 100f
                if (!started) {
                    stroke.moveTo(x, y)
                    area.moveTo(x, bottom)
                    area.lineTo(x, y)
                    firstX = x
                    started = true
                } else {
                    stroke.lineTo(x, y)
                    area.lineTo(x, y)
                }
                lastX = x
                i++
            }
            area.lineTo(lastX, bottom)
            area.lineTo(firstX, bottom)
            area.close()
            canvas.drawPath(area, fill)
            canvas.drawPath(stroke, line)
        }
    }
}
