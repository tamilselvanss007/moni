package com.alpha.topmonitor.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import com.alpha.topmonitor.core.Format
import com.alpha.topmonitor.data.AnchorPosition
import com.alpha.topmonitor.data.OverlaySettings
import com.alpha.topmonitor.monitor.Snapshot
import kotlin.math.hypot

/**
 * Owns the floating window. Uses TYPE_APPLICATION_OVERLAY (the only overlay type allowed on
 * Android 8+, which is this app's minimum). The window is laid out below the status bar and
 * inside display cutouts, so it never covers notification icons.
 */
class OverlayController(
    private val context: Context,
    private val onPositionChanged: (x: Int, y: Int) -> Unit,
    private val onTap: () -> Unit
) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val density = context.resources.displayMetrics.density
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private val background = GradientDrawable()

    private var root: LinearLayout? = null
    private var primary: TextView? = null
    private var secondary: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var settings = OverlaySettings()
    private var last: Snapshot? = null
    private var attached = false

    /** Adds the window. Returns false if Android refuses (for example, permission revoked). */
    fun show(s: OverlaySettings): Boolean {
        settings = s
        if (attached) {
            apply(s)
            return true
        }
        val view = buildView()
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flagsFor(s),
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = gravityFor(s.anchor)
        lp.x = s.posX
        lp.y = s.posY
        lp.title = "TopMonitor"
        root = view
        params = lp
        applyStyle(s)
        render()
        return try {
            wm.addView(view, lp)
            attached = true
            true
        } catch (e: Exception) {
            root = null
            params = null
            false
        }
    }

    fun apply(s: OverlaySettings) {
        settings = s
        val lp = params ?: return
        applyStyle(s)
        lp.gravity = gravityFor(s.anchor)
        lp.x = s.posX
        lp.y = s.posY
        lp.flags = flagsFor(s)
        render()
        val view = root
        if (attached && view != null) {
            try {
                wm.updateViewLayout(view, lp)
            } catch (e: Exception) {
                // View already gone; nothing to update.
            }
        }
    }

    fun update(snapshot: Snapshot) {
        last = snapshot
        render()
    }

    fun setVisible(visible: Boolean) {
        root?.visibility = if (visible) View.VISIBLE else View.GONE
    }

    /** Called after rotation or a size change so the widget never ends up off screen. */
    fun onConfigurationChanged() {
        root?.post {
            val lp = params ?: return@post
            lp.x = clampX(lp.x, settings.anchor)
            lp.y = clampY(lp.y)
            val view = root
            if (attached && view != null) {
                try {
                    wm.updateViewLayout(view, lp)
                } catch (e: Exception) {
                    return@post
                }
            }
            onPositionChanged(lp.x, lp.y)
        }
    }

    fun remove() {
        val view = root
        if (attached && view != null) {
            try {
                wm.removeViewImmediate(view)
            } catch (e: Exception) {
                // Already removed.
            }
        }
        attached = false
        root = null
        primary = null
        secondary = null
        params = null
    }

    private fun dp(v: Int): Int = (v * density + 0.5f).toInt()

    @SuppressLint("ClickableViewAccessibility")
    private fun buildView(): LinearLayout {
        background.cornerRadius = dp(10).toFloat()
        val p = TextView(context).apply {
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            setSingleLine(true)
            includeFontPadding = false
        }
        val s = TextView(context).apply {
            typeface = Typeface.MONOSPACE
            includeFontPadding = false
            setPadding(0, dp(2), 0, 0)
        }
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
            this.background = this@OverlayController.background
            addView(p)
            addView(s)
        }
        container.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            private var startX = 0
            private var startY = 0
            private var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val lp = params ?: return false
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX
                        downY = e.rawY
                        startX = lp.x
                        startY = lp.y
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (!moved && hypot(dx, dy) > touchSlop) moved = true
                        if (moved) {
                            val sign = if (settings.anchor == AnchorPosition.RIGHT) -1 else 1
                            lp.x = clampX(startX + (sign * dx).toInt(), settings.anchor)
                            lp.y = clampY(startY + dy.toInt())
                            try {
                                wm.updateViewLayout(v, lp)
                            } catch (ex: Exception) {
                                return false
                            }
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) onPositionChanged(lp.x, lp.y) else onTap()
                        return true
                    }
                    MotionEvent.ACTION_CANCEL -> return true
                }
                return false
            }
        })
        primary = p
        secondary = s
        return container
    }

    private fun applyStyle(s: OverlaySettings) {
        val p = primary ?: return
        val sec = secondary ?: return
        p.setTextColor(s.textColor)
        sec.setTextColor(s.textColor)
        p.setTextSize(TypedValue.COMPLEX_UNIT_SP, s.textSizeSp.toFloat())
        sec.setTextSize(TypedValue.COMPLEX_UNIT_SP, s.textSizeSp * 0.82f)
        val alpha = s.bgOpacityPercent.coerceIn(0, 100) * 255 / 100
        background.setColor(ColorUtils.setAlphaComponent(s.bgColor, alpha))
        sec.visibility = if (s.expanded) View.VISIBLE else View.GONE
    }

    private fun render() {
        val p = primary ?: return
        val sec = secondary ?: return
        val snap = last
        if (snap == null) {
            p.text = "TopMonitor…"
            sec.text = ""
            return
        }
        val s = settings
        val parts = ArrayList<String>(3)
        if (s.showCpu) parts.add("CPU " + Format.percent(snap.cpu.systemPercent))
        if (s.showRam) {
            parts.add("RAM " + Format.percent(snap.ram.percent))
            if (s.showRamDetail) {
                parts.add(Format.gb(snap.ram.usedBytes) + "/" + Format.gb(snap.ram.totalBytes) + " GB")
            }
        }
        p.text = if (parts.isEmpty()) "—" else parts.joinToString(" | ")

        if (s.expanded) {
            val pss = snap.ram.appPssBytes?.let { Format.mb(it) + " MB" } ?: "n/a"
            val line1 = "App CPU " + Format.percent(snap.cpu.appPercent) + " · App RAM " + pss
            val freq = Format.freq(snap.cpu.avgFreqKhz)
            val line2 = snap.cpu.cores.toString() + " cores" +
                (if (freq != null) " @ $freq (reported)" else "")
            sec.text = line1 + "\n" + line2
        }
    }

    private fun flagsFor(s: OverlaySettings): Int {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        if (s.clickThrough) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return f
    }

    private fun gravityFor(a: AnchorPosition): Int = Gravity.TOP or when (a) {
        AnchorPosition.LEFT -> Gravity.START
        AnchorPosition.CENTER -> Gravity.CENTER_HORIZONTAL
        AnchorPosition.RIGHT -> Gravity.END
    }

    private fun clampX(x: Int, anchor: AnchorPosition): Int {
        val screenW = context.resources.displayMetrics.widthPixels
        val room = (screenW - (root?.width ?: 0)).coerceAtLeast(0)
        return if (anchor == AnchorPosition.CENTER) x.coerceIn(-room / 2, room / 2) else x.coerceIn(0, room)
    }

    private fun clampY(y: Int): Int {
        val screenH = context.resources.displayMetrics.heightPixels
        val room = (screenH - (root?.height ?: 0)).coerceAtLeast(0)
        return y.coerceIn(0, room)
    }
}
