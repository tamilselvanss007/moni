package com.alpha.topmonitor.data

import com.alpha.topmonitor.monitor.HistoryPoint
import com.alpha.topmonitor.monitor.Snapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * In-memory hub shared by the overlay service and the dashboard.
 * History stays on the device and is dropped when the process ends.
 */
object PerformanceRepository {
    const val MAX_POINTS = 120

    private val _latest = MutableStateFlow<Snapshot?>(null)
    val latest: StateFlow<Snapshot?> = _latest.asStateFlow()

    private val _history = MutableStateFlow<List<HistoryPoint>>(emptyList())
    val history: StateFlow<List<HistoryPoint>> = _history.asStateFlow()

    private val _serviceRunning = MutableStateFlow(false)
    val serviceRunning: StateFlow<Boolean> = _serviceRunning.asStateFlow()

    fun publish(s: Snapshot) {
        _latest.value = s
        val point = HistoryPoint(s.timeMs, s.cpu.systemPercent, s.ram.percent)
        _history.update { (it + point).takeLast(MAX_POINTS) }
    }

    fun setServiceRunning(running: Boolean) {
        _serviceRunning.value = running
    }
}
