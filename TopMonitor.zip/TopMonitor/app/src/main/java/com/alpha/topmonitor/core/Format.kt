package com.alpha.topmonitor.core

import java.util.Locale

object Format {
    private const val GIB = 1024.0 * 1024.0 * 1024.0
    private const val MIB = 1024L * 1024L

    /** Binary gigabytes (1 GB = 1024 MB), the same basis Android's memory screens use. */
    fun gb(bytes: Long): String = String.format(Locale.US, "%.1f", bytes / GIB)

    fun mb(bytes: Long): String = (bytes / MIB).toString()

    fun percent(value: Float?): String =
        if (value == null) "N/A" else String.format(Locale.US, "%d%%", Math.round(value))

    fun freq(khz: Long?): String? {
        if (khz == null || khz <= 0L) return null
        return if (khz >= 1_000_000L) String.format(Locale.US, "%.2f GHz", khz / 1_000_000.0)
        else String.format(Locale.US, "%d MHz", khz / 1000L)
    }
}
