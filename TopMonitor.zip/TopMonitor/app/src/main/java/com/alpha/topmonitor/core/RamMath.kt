package com.alpha.topmonitor.core

object RamMath {
    /** Used = total - available (the figure ActivityManager.MemoryInfo exposes), never negative. */
    fun usedBytes(total: Long, avail: Long): Long {
        if (total <= 0L) return 0L
        return (total - avail).coerceIn(0L, total)
    }

    fun percent(total: Long, avail: Long): Float? {
        if (total <= 0L) return null
        return usedBytes(total, avail).toFloat() / total.toFloat() * 100f
    }
}
