package com.alpha.topmonitor.core

/** Aggregate jiffies read from the first "cpu" line of /proc/stat. */
data class CpuTimes(val busy: Long, val total: Long)

/** Pure calculation helpers, kept free of Android classes so they can be unit tested on the JVM. */
object CpuMath {

    /**
     * Parses the aggregate line ("cpu  user nice system idle iowait irq softirq steal ...").
     * Returns null when the text is empty or malformed.
     */
    fun parseProcStat(text: String): CpuTimes? {
        val line = text.lineSequence().firstOrNull { it.startsWith("cpu ") } ?: return null
        val fields = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (fields.size < 4) return null
        // Only the first eight fields count; guest time is already included in user/nice.
        val counted = fields.take(8)
        val total = counted.sum()
        val idle = fields[3] + (fields.getOrNull(4) ?: 0L)
        return CpuTimes(busy = total - idle, total = total)
    }

    /** System-wide utilisation between two readings, or null when the counters did not advance. */
    fun usagePercent(prev: CpuTimes, cur: CpuTimes): Float? {
        val dTotal = cur.total - prev.total
        val dBusy = cur.busy - prev.busy
        if (dTotal <= 0L || dBusy < 0L) return null
        return (dBusy.toFloat() / dTotal.toFloat() * 100f).coerceIn(0f, 100f)
    }

    /** Share of the whole device's CPU capacity that this process used during the interval. */
    fun appPercent(deltaCpuMs: Long, deltaWallMs: Long, cores: Int): Float? {
        if (deltaCpuMs < 0L || deltaWallMs <= 0L || cores <= 0) return null
        return (deltaCpuMs.toFloat() / (deltaWallMs.toFloat() * cores) * 100f).coerceIn(0f, 100f)
    }
}
