# TopMonitor – CPU & RAM Overlay

A small native Android app (Kotlin, XML views, Material 3) that draws a live CPU and RAM readout
above other apps. Minimum Android 8.0 (API 26), target API 35.

## Download

Every push to `main` builds a signed APK on GitHub Actions and publishes it as a release.
The newest build is always at:

    https://github.com/<your-user>/TopMonitor/releases/latest/download/TopMonitor.apk

Open that link on your phone, allow "install unknown apps" for your browser when asked, and install.

## What it does

- Floating widget: `CPU 32% | RAM 68% | 3.2/8.0 GB`, drag to move, tap to switch compact / expanded.
- Position presets (left, centre, right), opacity, text size, text colour, background colour.
- Show or hide CPU and RAM separately. Touch-through option for gaming (locks the position).
- Dashboard with live CPU and RAM cards and a two-minute history chart for each.
- Foreground service with a notification that has **Stop** and **Hide/Show** buttons.
- Settings are saved with DataStore. No network access, no analytics, no accounts.

## What the numbers mean (and don't)

| Figure | Source | Notes |
|---|---|---|
| System RAM used / available / total | `ActivityManager.MemoryInfo` | Used = total − available. 1 GB = 1024 MB. |
| This app's memory | `Debug.getMemoryInfo` (PSS) | Shown separately from system RAM. |
| System CPU % | `/proc/stat` | **Often blocked.** See below. |
| This app's CPU % | `Process.getElapsedCpuTime()` | Share of total capacity across all cores. |
| CPU frequency | `/sys/.../cpufreq/scaling_cur_freq` | What the kernel reports, not a measured clock. Often unreadable. |

**System-wide CPU on modern Android.** From Android 8 onward most devices stop normal apps from
reading `/proc/stat`. TopMonitor tries it, and after three failed reads it shows **N/A** and says why
in the dashboard. It never estimates, smooths or invents a CPU figure. Some devices (older
phones, some emulators, some custom ROMs) still allow it, and there you get a real value.
The app also does not use root, Accessibility or device-admin tricks to get around this.

It cannot free RAM, change CPU speed or read GPU temperature, and it does not claim to.

## Permissions

| Permission | Why | When asked |
|---|---|---|
| Display over other apps (`SYSTEM_ALERT_WINDOW`) | Draw the widget above other apps | When you first switch the overlay on |
| Notifications (`POST_NOTIFICATIONS`, Android 13+) | Show the Stop / Hide controls | When you first switch the overlay on |
| Foreground service (+ special-use type) | Keep sampling while another app is open | Granted at install |

## Build it yourself

Requirements: JDK 17, Android Studio (Koala or newer) or just the command line with the Android SDK
(platform 35).

```
./gradlew testDebugUnitTest      # unit tests (pure JVM)
./gradlew assembleDebug          # app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease        # app/build/outputs/apk/release/app-release.apk (signed)
```

### Signing

`keystore/topmonitor-release.jks` is a **convenience key for sideloading**, committed to the repo so
that every CI build is signed with the same key and installs as an update. Anyone with the repo
can sign an APK with it, so do not publish to Google Play with it. To use your own key, set the
environment variables `TM_STORE_PASSWORD`, `TM_KEY_ALIAS` and `TM_KEY_PASSWORD` and replace the
keystore file (or add them as repository secrets and adjust the workflow).

## Project layout

```
app/src/main/java/com/alpha/topmonitor/
  core/      CpuMath, RamMath, Format       pure calculations (unit tested)
  monitor/   CpuMonitor, RamMonitor, Models  system readings
  data/      SettingsRepository (DataStore), PerformanceRepository (in-memory history)
  overlay/   OverlayController               WindowManager window, drag, clamp
  service/   FloatingOverlayService          sampling loop + notification (single service)
  ui/        MainActivity, SparklineView     dashboard and custom chart
  util/      Permissions
```

## Manual test plan (real device)

1. **Permission denied path.** Fresh install, switch overlay on, leave the settings screen without
   enabling the permission. Expect a message and the switch back off.
2. **Permission granted path.** Allow it, return. Overlay appears under the status bar.
3. **Over other apps.** Open a browser, a video, a game. The widget stays visible.
4. **Drag and presets.** Drag it, kill the app from recents, relaunch. Position is kept. Tap Reset.
5. **Rotation.** Rotate with the widget at the right edge. It stays on screen.
6. **Compact / expanded.** Tap the widget. A second block with app CPU, app RAM and core count appears.
7. **Notification.** Hide, then Show, then Stop. Stop removes the widget and the notification and the
   dashboard switch turns off.
8. **Process death.** Swipe the app away with the overlay on, then reopen it. The overlay returns.
9. **Cross-check RAM.** Compare used/total with Settings → About phone or Developer options → Running
   services; they should agree within normal fluctuation.
10. **CPU.** If the card shows N/A, that is the Android restriction described above. If it shows a
    value, compare with a terminal `top` or `cat /proc/stat` run through adb.
11. **Battery.** Leave it running for an hour with the screen on, then check
    Settings → Battery usage. Sampling reads a few small files per second.
12. **Versions and sizes.** Try Android 8, 12, 13 and 14+, a small phone and a tablet.

Automated: `RamMonitorInstrumentedTest` (run with `./gradlew connectedDebugAndroidTest` on a device
or emulator).

## Troubleshooting

- **Widget disappears after a while.** Open the dashboard → Background running → battery settings and set
  TopMonitor to unrestricted. Some makers (Xiaomi, Oppo, Vivo, Huawei) also need "Autostart" or
  "Lock in recents".
- **Cannot enable the permission.** Some phones hide the page under Settings → Apps → Special access →
  Display over other apps.
- **"App not installed".** An APK signed with a different key is already installed. Uninstall it first.
- **CPU shows N/A.** Expected on most Android 8+ devices. See "What the numbers mean".
- **No stop button in the notification.** Notification permission is off. The overlay still works; use the
  dashboard's Stop all monitoring button.

## Limitations

- System CPU is unavailable on most current devices (see above). This is a platform limit, not a bug.
- Per-core frequency files are often unreadable; the app shows nothing rather than guess.
- History is kept in memory for the current session only.
- The overlay cannot appear over the lock screen, system dialogs or some secure windows.
- Release builds are not minified.
